# 🛡️ NyxGuard — Proteção de Scripts Lua

Site completo para gerar loadstrings protegidas para scripts Roblox.  
Frontend no **GitHub Pages** · Backend no **Cloudflare Workers** (gratuito)

---

## Como o sistema funciona

```
Usuário cola código → Worker encripta com XOR+Base64 (chave nova por execução)
→ Gera loadstring → No executor: loadstring(game:HttpGet(URL))()
→ Worker retorna Lua ofuscada → Decodifica e executa o script original
```

O código original **nunca é transmitido em texto puro**.  
Cada execução recebe um loader diferente (chave nova + nomes de variáveis novos).

---

## Setup — Passo a Passo

### 1. Cloudflare Workers + KV (backend)

**Requisitos:** Node.js 18+, conta Cloudflare gratuita

```bash
cd worker
npm install

# Criar o namespace KV
npx wrangler kv:namespace create SCRIPTS
# Copie o "id" que aparecer na saída

# Edite wrangler.toml e substitua COLE_O_ID_AQUI pelo id copiado

# Fazer deploy
npx wrangler deploy
```

Após o deploy, o Worker estará em:  
`https://nyxguard.SEU_USUARIO.workers.dev`

---

### 2. Configurar o frontend

Edite o arquivo `assets/js/config.js`:

```js
window.NYX = {
  WORKER: 'https://nyxguard.SEU_USUARIO.workers.dev', // ← coloque sua URL aqui
};
```

---

### 3. GitHub Pages (frontend)

```bash
# Na raiz do projeto (onde estão index.html e dashboard.html):
git init
git add .
git commit -m "NyxGuard v1"
git remote add origin https://github.com/SEU_USUARIO/SEU_REPO.git
git push -u origin main
```

No GitHub: **Settings → Pages → Source: Deploy from branch → main / (root)**

Seu site estará em: `https://SEU_USUARIO.github.io/SEU_REPO/`

---

## Funcionalidades

| Feature | Descrição |
|---------|-----------|
| **Editor com linha** | Editor completo com numeração de linhas |
| **Upload .lua** | Arraste ou clique para carregar arquivo |
| **Sem limite de tamanho** | Aceita scripts de até 2 MB |
| **Ofuscação dupla** | XOR 32 bytes + Base64, nomes de variável aleatórios a cada request |
| **Chave única por execução** | Mesmo script, loader completamente diferente cada vez |
| **Lock por GameId** | Bloqueia execução em jogos não autorizados |
| **Whitelist / Blacklist** | Controle de acesso por IP |
| **Log de acessos** | Registra IP, User-Agent e horário dos últimos 100 acessos |
| **Dashboard** | Gerencia todos os scripts criados, salvo no localStorage |
| **Atualizar código** | Atualiza o source sem mudar o loadstring |
| **Loading animado** | Notificação e print antes de executar |

---

## Uso no executor

```lua
loadstring(game:HttpGet("https://nyxguard.SEU_USUARIO.workers.dev/s/ID_DO_SCRIPT", true))()
```

---

## API (para uso avançado)

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| `POST` | `/api/scripts` | Cria script |
| `GET` | `/s/:id` | Retorna loader ofuscado |
| `GET` | `/api/scripts/:id` | Info do script (token admin) |
| `PUT` | `/api/scripts/:id` | Atualiza configurações/source |
| `DELETE` | `/api/scripts/:id` | Deleta script |

Header de autenticação: `X-Admin-Token: SEU_TOKEN`

---

## Tier gratuito do Cloudflare Workers

- 100.000 requests/dia grátis
- KV: 100.000 leituras/dia, 1.000 escritas/dia
- Mais que suficiente para uso pessoal
