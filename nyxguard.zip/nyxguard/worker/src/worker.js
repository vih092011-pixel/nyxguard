/**
 * NyxGuard — Cloudflare Worker
 * API + Obfuscation engine + Loader serving
 * KV namespace: SCRIPTS
 */

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, X-Admin-Token',
};

// ── helpers ──────────────────────────────────────────────────────────────────

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS },
  });
}
function err(msg, status = 400) {
  return json({ ok: false, error: msg }, status);
}
function luaErr(msg) {
  return new Response(`error(${JSON.stringify('[NyxGuard] ' + msg)}, 0)`, {
    status: 200,
    headers: { 'Content-Type': 'text/plain', ...CORS },
  });
}

function genId(len = 16) {
  const b = new Uint8Array(len);
  crypto.getRandomValues(b);
  return Array.from(b).map(x => x.toString(16).padStart(2, '0')).join('').slice(0, len);
}

function b64Encode(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s);
}

function xorEncode(source, key) {
  const src = new TextEncoder().encode(source);
  const out = new Uint8Array(src.length);
  for (let i = 0; i < src.length; i++) out[i] = src[i] ^ key[i % key.length];
  return out;
}

function splitChunks(str, size) {
  const r = [];
  for (let i = 0; i < str.length; i += size) r.push(str.slice(i, i + size));
  return r;
}

// ── Lua obfuscator ───────────────────────────────────────────────────────────

let _idCounter = 0;
function freshId() {
  _idCounter = (_idCounter + 1) % 100000;
  const rnd = Math.floor(Math.random() * 0xFFFF).toString(16).padStart(4, '0');
  return `_${(_idCounter + 0x1000).toString(16)}${rnd}`;
}

const JUNK_LINES = [
  () => `local ${freshId()} = type(nil)`,
  () => `local ${freshId()} = math.abs(${Math.floor(Math.random() * 999 + 1)})`,
  () => `local ${freshId()} = string.len("${'x'.repeat(Math.floor(Math.random() * 6) + 1)}")`,
  () => `local ${freshId()} = select(${Math.floor(Math.random() * 3) + 1}, 0, 1, 2)`,
  () => `if false then local ${freshId()} = error end`,
  () => `do local ${freshId()} = rawequal(0,0) end`,
  () => `local ${freshId()}; ${freshId()} = nil`,
];

function junkLine() {
  return JUNK_LINES[Math.floor(Math.random() * JUNK_LINES.length)]();
}

function scatter(arr, times = 3) {
  // Insert junk lines at random positions in an array of lines
  const result = [...arr];
  for (let i = 0; i < times; i++) {
    const pos = Math.floor(Math.random() * (result.length + 1));
    result.splice(pos, 0, junkLine());
  }
  return result;
}

function generateLoader(source, scriptId, gameLock) {
  _idCounter = 0; // reset per-request

  // Fresh 32-byte XOR key every request
  const key = new Uint8Array(32);
  crypto.getRandomValues(key);

  const encoded = xorEncode(source, key);
  const b64 = b64Encode(encoded);
  const dataChunks = splitChunks(b64, 70);

  // All variable names are random
  const V = {};
  const names = [
    'data','key','klen','b64fn','xorfn','main','sb','sc','tc','pcall_',
    'load_','ok','er','tmp','tmp2','tmp3','out','i','j','n',
    'alpha','lkup','c1','c2','c3','c4','res','sg','bxor','band',
    'bshl','bshr','bits','bit32_'
  ];
  for (const n of names) V[n] = freshId();

  // Key table: bytes stored at indices 1..32, plus junk entries at high indices
  const keyEntries = [];
  for (let i = 0; i < key.length; i++) keyEntries.push(`[${i + 1}]=${key[i]}`);
  // Add junk entries at indices 101..120
  for (let i = 0; i < 10; i++) {
    keyEntries.push(`[${101 + i}]=${Math.floor(Math.random() * 256)}`);
  }
  // Shuffle
  keyEntries.sort(() => Math.random() - 0.5);
  const keyTable = keyEntries.join(',');

  // Data table
  const dataTable = dataChunks.map((c, i) => `[${i + 1}]=${JSON.stringify(c)}`).join(',\n    ');

  // Split the base64 alphabet into two string.char reconstructed halves
  // to avoid easy grep for "ABCDE..."
  const alphabetChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  const alphaBytes = Array.from(alphabetChars).map(c => c.charCodeAt(0));
  const alphaCalls = alphaBytes.map(b => `${V.sc}(${b})`).join('..');

  const gameLockCode = gameLock
    ? `if game.PlaceId ~= ${gameLock} then error("[NyxGuard] Jogo nao autorizado.", 0) return end\n`
    : '';

  // Build the script as an array of lines then scatter junk
  const headerLines = [
    `-- NyxGuard | ${scriptId} | Protected`,
    `-- Regenerado a cada execucao. Deofuscacao invalida.`,
    ``,
    `local ${V.sb}=string.byte`,
    `local ${V.sc}=string.char`,
    `local ${V.tc}=table.concat`,
    `local ${V.pcall_}=pcall`,
    `local ${V.load_}=loadstring or load`,
  ];

  const bitLines = [
    `local ${V.bit32_}=bit32`,
    `local ${V.bxor}=${V.bit32_} and ${V.bit32_}.bxor or function(${V.tmp},${V.tmp2})`,
    `  local ${V.res},${V.bits}=0,1`,
    `  while ${V.tmp}>0 or ${V.tmp2}>0 do`,
    `    local ra,rb=${V.tmp}%2,${V.tmp2}%2`,
    `    if ra~=rb then ${V.res}=${V.res}+${V.bits} end`,
    `    ${V.tmp}=math.floor(${V.tmp}/2)`,
    `    ${V.tmp2}=math.floor(${V.tmp2}/2)`,
    `    ${V.bits}=${V.bits}*2`,
    `  end`,
    `  return ${V.res}`,
    `end`,
    `local ${V.band}=${V.bit32_} and ${V.bit32_}.band or function(${V.tmp},${V.tmp2}) return ${V.tmp}-(${V.tmp}%1)-(${V.tmp2}%1)+((${V.tmp}%1)*${V.tmp2}%1) end`,
    `local ${V.bshl}=${V.bit32_} and ${V.bit32_}.lshift or function(${V.tmp},${V.tmp2}) return math.floor(${V.tmp}*(2^${V.tmp2}))%256 end`,
    `local ${V.bshr}=${V.bit32_} and ${V.bit32_}.rshift or function(${V.tmp},${V.tmp2}) return math.floor(${V.tmp}/(2^${V.tmp2})) end`,
  ];

  const dataLines = [
    `local ${V.data}={`,
    `    ${dataTable}`,
    `}`,
    `local ${V.key}={${keyTable}}`,
    `local ${V.klen}=32`,
  ];

  const b64FnLines = [
    `local ${V.b64fn}=function(${V.tmp})`,
    `  local ${V.alpha}=${alphaCalls}`,
    `  local ${V.lkup}={}`,
    `  for ${V.i}=1,#${V.alpha} do`,
    `    ${V.lkup}[${V.sb}(${V.alpha},${V.i},${V.i})]=${V.i}-1`,
    `  end`,
    `  local ${V.res}={}`,
    `  local ${V.n}=0`,
    `  for ${V.i}=1,#${V.tmp},4 do`,
    `    local ${V.c1}=${V.lkup}[${V.sb}(${V.tmp},${V.i},${V.i})] or 0`,
    `    local ${V.c2}=${V.lkup}[${V.sb}(${V.tmp},${V.i}+1,${V.i}+1)] or 0`,
    `    local ${V.c3}=${V.lkup}[${V.sb}(${V.tmp},${V.i}+2,${V.i}+2)]`,
    `    local ${V.c4}=${V.lkup}[${V.sb}(${V.tmp},${V.i}+3,${V.i}+3)]`,
    `    ${V.n}=${V.n}+1; ${V.res}[${V.n}]=${V.sc}(${V.bshl}(${V.c1},2)+${V.bshr}(${V.c2},4))`,
    `    if ${V.c3} then`,
    `      ${V.n}=${V.n}+1`,
    `      ${V.res}[${V.n}]=${V.sc}(${V.bshl}(${V.c2}%16,4)+${V.bshr}(${V.c3},2))`,
    `    end`,
    `    if ${V.c4} then`,
    `      ${V.n}=${V.n}+1`,
    `      ${V.res}[${V.n}]=${V.sc}(${V.c3}%4*64+${V.c4})`,
    `    end`,
    `  end`,
    `  return ${V.tc}(${V.res})`,
    `end`,
  ];

  const xorFnLines = [
    `local ${V.xorfn}=function(${V.tmp},${V.tmp2})`,
    `  local ${V.res}={}`,
    `  for ${V.i}=1,#${V.tmp} do`,
    `    local ${V.j}=((${V.i}-1)%${V.klen})+1`,
    `    ${V.res}[${V.i}]=${V.sc}(${V.bxor}(${V.sb}(${V.tmp},${V.i}),${V.tmp2}[${V.j}]))`,
    `  end`,
    `  return ${V.tc}(${V.res})`,
    `end`,
  ];

  const mainLines = [
    `local ${V.main}=function()`,
    gameLockCode,
    `  local ${V.sg}=game:GetService("StarterGui")`,
    `  local ${V.ok}=pcall(function()`,
    `    ${V.sg}:SetCore("SendNotification",{`,
    `      Title="NyxGuard",`,
    `      Text="Carregando script...",`,
    `      Duration=2,`,
    `      Icon="rbxassetid://6031068431"`,
    `    })`,
    `  end)`,
    `  if not ${V.ok} then`,
    `    task.spawn(function()`,
    `      for ${V.i}=1,3 do`,
    `        print("[NyxGuard] Carregando"..string.rep(".",${V.i}))`,
    `        task.wait(0.4)`,
    `      end`,
    `    end)`,
    `  end`,
    `  task.wait(0.05)`,
    `  local ${V.out}=""`,
    `  for ${V.i}=1,#${V.data} do ${V.out}=${V.out}..${V.data}[${V.i}] end`,
    `  local ${V.tmp}=${V.b64fn}(${V.out})`,
    `  local ${V.tmp2}=${V.xorfn}(${V.tmp},${V.key})`,
    `  local ${V.tmp3},${V.er}=${V.load_}(${V.tmp2})`,
    `  if not ${V.tmp3} then`,
    `    error("[NyxGuard] Erro ao carregar: "..(${V.er} or "?"),0)`,
    `    return`,
    `  end`,
    `  local ${V.ok},${V.er}=${V.pcall_}(${V.tmp3})`,
    `  if not ${V.ok} then`,
    `    warn("[NyxGuard] Erro de execucao: "..(${V.er} or "?"))`,
    `  end`,
    `end`,
    `${V.main}()`,
  ];

  // Merge everything and scatter junk throughout
  const allSections = [
    scatter(headerLines, 2),
    scatter(bitLines, 3),
    scatter(dataLines, 2),
    scatter(b64FnLines, 4),
    scatter(xorFnLines, 3),
    scatter(mainLines, 2),
  ];

  return allSections.flat().join('\n');
}

// ── route handlers ────────────────────────────────────────────────────────────

async function handleCreate(req, env) {
  let body;
  try { body = await req.json(); }
  catch { return err('JSON inválido'); }

  const source = body.source;
  if (typeof source !== 'string' || !source.trim()) return err('Código não pode estar vazio');
  if (source.length > 2_000_000) return err('Código muito grande (máx 2 MB)');

  const id = genId(16);
  const adminToken = genId(40);

  const doc = {
    id,
    source,
    adminToken,
    settings: {
      enabled: true,
      label: typeof body.label === 'string' ? body.label.slice(0, 80) : '',
      gameLock: typeof body.gameLock === 'number' ? body.gameLock : null,
      whitelistMode: body.whitelistMode === true,
      whitelist: [],
      blacklist: [],
    },
    stats: {
      hits: 0,
      created: Date.now(),
      lastHit: null,
    },
    log: [],
  };

  await env.SCRIPTS.put(`script:${id}`, JSON.stringify(doc));

  const origin = new URL(req.url).origin;
  return json({
    ok: true,
    id,
    adminToken,
    loadstring: `loadstring(game:HttpGet("${origin}/s/${id}", true))()`,
  }, 201);
}

async function handleLoader(req, env, id) {
  // Block browser access
  const accept = req.headers.get('Accept') || '';
  if (accept.includes('text/html')) {
    return new Response(
      `<html><head><title>404</title></head><body><h2>404 — Not Found</h2></body></html>`,
      { status: 404, headers: { 'Content-Type': 'text/html' } }
    );
  }

  const raw = await env.SCRIPTS.get(`script:${id}`);
  if (!raw) return luaErr('Script não encontrado ou removido.');

  const doc = JSON.parse(raw);

  if (!doc.settings.enabled) return luaErr('Script desativado pelo autor.');

  const ip = req.headers.get('CF-Connecting-IP') || 'unknown';

  // Blacklist check
  if (doc.settings.blacklist.includes(ip)) return luaErr('Acesso negado.');

  // Whitelist check
  if (doc.settings.whitelistMode && doc.settings.whitelist.length > 0) {
    if (!doc.settings.whitelist.includes(ip)) return luaErr('IP não autorizado.');
  }

  // Update stats (fire-and-forget)
  doc.stats.hits++;
  doc.stats.lastHit = Date.now();
  const logEntry = {
    ip,
    ua: (req.headers.get('User-Agent') || '').slice(0, 120),
    t: Date.now(),
  };
  doc.log = [logEntry, ...doc.log].slice(0, 100);
  env.SCRIPTS.put(`script:${id}`, JSON.stringify(doc)); // no await

  const loader = generateLoader(doc.source, id, doc.settings.gameLock);

  return new Response(loader, {
    headers: { 'Content-Type': 'text/plain', ...CORS },
  });
}

async function handleInfo(req, env, id) {
  const raw = await env.SCRIPTS.get(`script:${id}`);
  if (!raw) return err('Script não encontrado', 404);

  const doc = JSON.parse(raw);
  const token = req.headers.get('X-Admin-Token');
  if (doc.adminToken !== token) return err('Token inválido', 403);

  const { source: _, adminToken: __, ...safe } = doc;
  return json({ ok: true, script: safe });
}

async function handleUpdate(req, env, id) {
  const raw = await env.SCRIPTS.get(`script:${id}`);
  if (!raw) return err('Script não encontrado', 404);

  const doc = JSON.parse(raw);
  const token = req.headers.get('X-Admin-Token');
  if (doc.adminToken !== token) return err('Token inválido', 403);

  let body;
  try { body = await req.json(); }
  catch { return err('JSON inválido'); }

  if (body.settings) {
    const s = body.settings;
    if (typeof s.enabled === 'boolean') doc.settings.enabled = s.enabled;
    if (typeof s.label === 'string') doc.settings.label = s.label.slice(0, 80);
    if (s.gameLock !== undefined) doc.settings.gameLock = typeof s.gameLock === 'number' ? s.gameLock : null;
    if (typeof s.whitelistMode === 'boolean') doc.settings.whitelistMode = s.whitelistMode;
    if (Array.isArray(s.whitelist)) doc.settings.whitelist = s.whitelist.slice(0, 500);
    if (Array.isArray(s.blacklist)) doc.settings.blacklist = s.blacklist.slice(0, 500);
  }
  if (typeof body.source === 'string' && body.source.trim()) {
    if (body.source.length > 2_000_000) return err('Código muito grande');
    doc.source = body.source;
  }
  if (body.clearLog) doc.log = [];

  await env.SCRIPTS.put(`script:${id}`, JSON.stringify(doc));
  return json({ ok: true });
}

async function handleDelete(req, env, id) {
  const raw = await env.SCRIPTS.get(`script:${id}`);
  if (!raw) return err('Script não encontrado', 404);

  const doc = JSON.parse(raw);
  const token = req.headers.get('X-Admin-Token');
  if (doc.adminToken !== token) return err('Token inválido', 403);

  await env.SCRIPTS.delete(`script:${id}`);
  return json({ ok: true });
}

// ── entry point ───────────────────────────────────────────────────────────────

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: CORS });
    }

    const { pathname } = new URL(request.url);
    const method = request.method;

    // GET /s/:id  — serve loader
    const loaderM = pathname.match(/^\/s\/([0-9a-f]{8,40})$/i);
    if (loaderM && method === 'GET') return handleLoader(request, env, loaderM[1].toLowerCase());

    // POST /api/scripts — create
    if (pathname === '/api/scripts' && method === 'POST') return handleCreate(request, env);

    // /api/scripts/:id
    const scriptM = pathname.match(/^\/api\/scripts\/([0-9a-f]{8,40})$/i);
    if (scriptM) {
      const id = scriptM[1].toLowerCase();
      if (method === 'GET') return handleInfo(request, env, id);
      if (method === 'PUT') return handleUpdate(request, env, id);
      if (method === 'DELETE') return handleDelete(request, env, id);
    }

    return new Response('Not Found', { status: 404, headers: CORS });
  },
};
