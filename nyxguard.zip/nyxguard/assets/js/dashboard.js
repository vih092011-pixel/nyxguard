/* NyxGuard — dashboard.js */
(function () {
  'use strict';

  const $ = id => document.getElementById(id);
  const API = () => (window.NYX && window.NYX.WORKER) || '';

  let currentScript = null; // { id, adminToken, data }

  // ── saved list ────────────────────────────────────────────────────────────
  function getSaved() {
    try { return JSON.parse(localStorage.getItem('nyxguard_scripts') || '[]'); }
    catch { return []; }
  }

  function renderList() {
    const saved = getSaved();
    const list = $('saved-list');
    if (!saved.length) {
      list.innerHTML = '<p class="muted">Nenhum script salvo ainda. Crie um na página principal.</p>';
      return;
    }
    list.innerHTML = saved.map((s, i) => `
      <div class="saved-item" data-index="${i}">
        <div class="saved-left">
          <span class="saved-label">${escHtml(s.label || 'Sem nome')}</span>
          <span class="saved-id muted">${s.id}</span>
        </div>
        <button class="btn btn-sm" onclick="loadSaved(${i})">Carregar</button>
      </div>
    `).join('');
  }

  window.loadSaved = function (i) {
    const s = getSaved()[i];
    if (!s) return;
    $('input-id').value = s.id;
    $('input-token').value = s.adminToken;
    fetchScript();
  };

  // ── fetch script ──────────────────────────────────────────────────────────
  $('btn-load').addEventListener('click', fetchScript);
  $('input-token').addEventListener('keydown', e => { if (e.key === 'Enter') fetchScript(); });

  async function fetchScript() {
    const id = $('input-id').value.trim();
    const token = $('input-token').value.trim();
    if (!id || !token) { toast('Preencha ID e token admin', 'error'); return; }

    setLoading(true);
    try {
      const res = await fetch(`${API()}/api/scripts/${id}`, {
        headers: { 'X-Admin-Token': token },
      });
      const data = await res.json();
      if (!data.ok) { toast(data.error, 'error'); return; }
      currentScript = { id, adminToken: token, data: data.script };
      renderDashboard();
      $('dashboard-panel').classList.remove('hidden');
      $('dashboard-panel').scrollIntoView({ behavior: 'smooth' });
    } catch (e) {
      toast('Erro de conexão', 'error');
    } finally {
      setLoading(false);
    }
  }

  // ── render dashboard ──────────────────────────────────────────────────────
  function renderDashboard() {
    const { id, data } = currentScript;
    const s = data.settings;
    const st = data.stats;

    $('d-id').textContent = id;
    $('d-label').textContent = s.label || '—';
    $('d-hits').textContent = st.hits;
    $('d-created').textContent = new Date(st.created).toLocaleString('pt-BR');
    $('d-lasthit').textContent = st.lastHit ? new Date(st.lastHit).toLocaleString('pt-BR') : '—';
    $('d-status').textContent = s.enabled ? '✅ Ativo' : '❌ Desativado';
    $('d-status').className = s.enabled ? 'badge badge-green' : 'badge badge-red';
    $('d-gamelock').textContent = s.gameLock ? s.gameLock : '—';
    $('d-wlmode').textContent = s.whitelistMode ? 'Whitelist ativa' : 'Acesso aberto';

    $('toggle-enabled').checked = s.enabled;

    // loadstring
    const origin = API();
    $('d-loadstring').value = `loadstring(game:HttpGet("${origin}/s/${id}", true))()`;

    // whitelist
    renderIpList('wl-list', s.whitelist, 'whitelist');
    renderIpList('bl-list', s.blacklist, 'blacklist');

    // log
    renderLog(data.log || []);
  }

  function renderIpList(containerId, list, kind) {
    const el = $(containerId);
    if (!list.length) {
      el.innerHTML = '<span class="muted">Vazia</span>';
      return;
    }
    el.innerHTML = list.map(ip => `
      <span class="ip-tag">
        ${escHtml(ip)}
        <button class="ip-remove" onclick="removeIp('${kind}','${escHtml(ip)}')" title="Remover">×</button>
      </span>
    `).join('');
  }

  function renderLog(log) {
    const el = $('access-log');
    if (!log.length) {
      el.innerHTML = '<p class="muted">Sem acessos registrados ainda.</p>';
      return;
    }
    el.innerHTML = `
      <table class="log-table">
        <thead><tr><th>IP</th><th>User-Agent</th><th>Hora</th></tr></thead>
        <tbody>
          ${log.map(entry => `
            <tr>
              <td>${escHtml(entry.ip)}</td>
              <td class="ua-cell">${escHtml(entry.ua)}</td>
              <td>${new Date(entry.t).toLocaleString('pt-BR')}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  }

  // ── toggle enabled ────────────────────────────────────────────────────────
  $('toggle-enabled').addEventListener('change', async e => {
    await updateSetting({ enabled: e.target.checked });
    toast(e.target.checked ? 'Script ativado' : 'Script desativado');
  });

  // ── update label ──────────────────────────────────────────────────────────
  $('btn-update-label').addEventListener('click', async () => {
    const label = $('d-label-input').value.trim();
    if (!label) return;
    await updateSetting({ label });
    currentScript.data.settings.label = label;
    renderDashboard();
    toast('Nome atualizado');
  });

  // ── update source ─────────────────────────────────────────────────────────
  $('btn-update-source').addEventListener('click', async () => {
    const source = $('d-source').value.trim();
    if (!source) { toast('Cole o novo código', 'error'); return; }
    const { id, adminToken } = currentScript;
    setLoading(true);
    try {
      const res = await fetch(`${API()}/api/scripts/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'X-Admin-Token': adminToken },
        body: JSON.stringify({ source }),
      });
      const data = await res.json();
      if (data.ok) toast('Código atualizado! Próximos loads usarão o novo código.', 'success');
      else toast(data.error, 'error');
    } catch { toast('Erro de conexão', 'error'); }
    finally { setLoading(false); }
  });

  // ── add IP ────────────────────────────────────────────────────────────────
  async function addIp(kind, inputId) {
    const ip = $(inputId).value.trim();
    if (!ip) return;
    const s = currentScript.data.settings;
    const list = kind === 'whitelist' ? [...s.whitelist] : [...s.blacklist];
    if (list.includes(ip)) { toast('IP já na lista', 'error'); return; }
    list.push(ip);
    const patch = kind === 'whitelist' ? { whitelist: list } : { blacklist: list };
    await updateSetting(patch);
    if (kind === 'whitelist') s.whitelist = list; else s.blacklist = list;
    renderDashboard();
    $(inputId).value = '';
    toast('IP adicionado');
  }

  window.removeIp = async function (kind, ip) {
    const s = currentScript.data.settings;
    if (kind === 'whitelist') s.whitelist = s.whitelist.filter(x => x !== ip);
    else s.blacklist = s.blacklist.filter(x => x !== ip);
    const patch = kind === 'whitelist' ? { whitelist: s.whitelist } : { blacklist: s.blacklist };
    await updateSetting(patch);
    renderDashboard();
    toast('IP removido');
  };

  $('btn-add-wl').addEventListener('click', () => addIp('whitelist', 'input-wl'));
  $('btn-add-bl').addEventListener('click', () => addIp('blacklist', 'input-bl'));

  // ── whitelist mode toggle ─────────────────────────────────────────────────
  $('toggle-wl-mode').addEventListener('change', async e => {
    await updateSetting({ whitelistMode: e.target.checked });
    currentScript.data.settings.whitelistMode = e.target.checked;
    renderDashboard();
    toast(e.target.checked ? 'Modo whitelist ativado' : 'Modo whitelist desativado');
  });

  // ── clear log ─────────────────────────────────────────────────────────────
  $('btn-clear-log').addEventListener('click', async () => {
    if (!confirm('Limpar log de acessos?')) return;
    const { id, adminToken } = currentScript;
    const res = await fetch(`${API()}/api/scripts/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', 'X-Admin-Token': adminToken },
      body: JSON.stringify({ clearLog: true }),
    });
    const data = await res.json();
    if (data.ok) {
      currentScript.data.log = [];
      renderLog([]);
      toast('Log limpo');
    }
  });

  // ── copy loadstring ───────────────────────────────────────────────────────
  $('btn-copy-d').addEventListener('click', () => {
    navigator.clipboard.writeText($('d-loadstring').value)
      .then(() => toast('Copiado!', 'success'))
      .catch(() => { $('d-loadstring').select(); document.execCommand('copy'); });
  });

  // ── delete ────────────────────────────────────────────────────────────────
  $('btn-delete').addEventListener('click', async () => {
    if (!confirm('Deletar este script permanentemente? O loadstring vai parar de funcionar.')) return;
    const { id, adminToken } = currentScript;
    setLoading(true);
    try {
      const res = await fetch(`${API()}/api/scripts/${id}`, {
        method: 'DELETE',
        headers: { 'X-Admin-Token': adminToken },
      });
      const data = await res.json();
      if (data.ok) {
        // Remove from localStorage
        const saved = getSaved().filter(s => s.id !== id);
        localStorage.setItem('nyxguard_scripts', JSON.stringify(saved));
        renderList();
        $('dashboard-panel').classList.add('hidden');
        currentScript = null;
        toast('Script deletado.', 'success');
      } else toast(data.error, 'error');
    } catch { toast('Erro de conexão', 'error'); }
    finally { setLoading(false); }
  });

  // ── helpers ───────────────────────────────────────────────────────────────
  async function updateSetting(patch) {
    const { id, adminToken } = currentScript;
    try {
      const res = await fetch(`${API()}/api/scripts/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'X-Admin-Token': adminToken },
        body: JSON.stringify({ settings: patch }),
      });
      const data = await res.json();
      if (!data.ok) toast(data.error, 'error');
      return data.ok;
    } catch { toast('Erro de conexão', 'error'); return false; }
  }

  function setLoading(v) {
    $('btn-load').disabled = v;
    $('btn-load').textContent = v ? 'Carregando...' : 'Carregar Script';
  }

  function escHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function toast(msg, type = 'info') {
    const t = document.createElement('div');
    t.className = `toast toast-${type}`;
    t.textContent = msg;
    $('toast-container').appendChild(t);
    requestAnimationFrame(() => t.classList.add('show'));
    setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, 3200);
  }

  // ── file upload for source update ─────────────────────────────────────────
  $('btn-upload-src').addEventListener('click', () => $('file-src').click());
  $('file-src').addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      $('d-source').value = ev.target.result;
      toast(`📄 ${file.name} carregado`);
    };
    reader.readAsText(file, 'utf-8');
    e.target.value = '';
  });

  // ── init ──────────────────────────────────────────────────────────────────
  renderList();
})();
