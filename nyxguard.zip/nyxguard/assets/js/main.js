/* NyxGuard — main.js */
(function () {
  'use strict';

  const $ = id => document.getElementById(id);
  const API = () => (window.NYX && window.NYX.WORKER) || '';

  // ── editor line numbers ──────────────────────────────────────────────────
  const editor = $('editor');
  const lineNums = $('line-nums');

  function updateLines() {
    const lines = (editor.value.match(/\n/g) || []).length + 1;
    lineNums.innerHTML = Array.from({ length: lines }, (_, i) =>
      `<span>${i + 1}</span>`
    ).join('');
  }

  editor.addEventListener('input', updateLines);
  editor.addEventListener('scroll', () => {
    lineNums.scrollTop = editor.scrollTop;
  });
  editor.addEventListener('keydown', e => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const s = editor.selectionStart, en = editor.selectionEnd;
      editor.value = editor.value.slice(0, s) + '    ' + editor.value.slice(en);
      editor.selectionStart = editor.selectionEnd = s + 4;
      updateLines();
    }
  });
  updateLines();

  // ── file upload ──────────────────────────────────────────────────────────
  $('btn-upload').addEventListener('click', () => $('file-input').click());
  $('file-input').addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.name.endsWith('.lua') && !file.name.endsWith('.txt')) {
      toast('Apenas arquivos .lua ou .txt', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = ev => {
      editor.value = ev.target.result;
      updateLines();
      toast(`📄 ${file.name} carregado`);
    };
    reader.readAsText(file, 'utf-8');
    e.target.value = '';
  });

  // drag & drop onto editor
  editor.addEventListener('dragover', e => { e.preventDefault(); editor.classList.add('drag'); });
  editor.addEventListener('dragleave', () => editor.classList.remove('drag'));
  editor.addEventListener('drop', e => {
    e.preventDefault();
    editor.classList.remove('drag');
    const file = e.dataTransfer.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => { editor.value = ev.target.result; updateLines(); };
    reader.readAsText(file, 'utf-8');
  });

  // ── char counter ─────────────────────────────────────────────────────────
  editor.addEventListener('input', () => {
    const bytes = new TextEncoder().encode(editor.value).length;
    $('char-count').textContent = `${(bytes / 1024).toFixed(1)} KB`;
  });

  // ── game lock toggle ─────────────────────────────────────────────────────
  $('toggle-gamelock').addEventListener('change', e => {
    $('gamelock-row').style.display = e.target.checked ? 'flex' : 'none';
  });

  // ── generate ─────────────────────────────────────────────────────────────
  $('btn-generate').addEventListener('click', async () => {
    const source = editor.value.trim();
    if (!source) { toast('Cole ou carregue um script primeiro', 'error'); return; }

    const workerUrl = API();
    if (!workerUrl || workerUrl.includes('SEU_USUARIO')) {
      toast('Configure o WORKER_URL em assets/js/config.js', 'error');
      return;
    }

    const gameLockEnabled = $('toggle-gamelock').checked;
    const gameLockVal = parseInt($('gamelock-id').value) || null;
    const whitelistMode = $('toggle-whitelist').checked;
    const label = $('script-label').value.trim();

    $('btn-generate').disabled = true;
    $('btn-generate').textContent = 'Gerando...';

    try {
      const res = await fetch(`${workerUrl}/api/scripts`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          source,
          label: label || 'Sem nome',
          gameLock: gameLockEnabled && gameLockVal ? gameLockVal : null,
          whitelistMode,
        }),
      });

      const data = await res.json();
      if (!data.ok) { toast(data.error || 'Erro desconhecido', 'error'); return; }

      // Show output
      $('output-section').classList.remove('hidden');
      $('out-loadstring').value = data.loadstring;
      $('out-id').textContent = data.id;

      // Store in localStorage
      const saved = getSaved();
      saved.unshift({
        id: data.id,
        adminToken: data.adminToken,
        label: label || 'Sem nome',
        created: Date.now(),
        loadstring: data.loadstring,
      });
      localStorage.setItem('nyxguard_scripts', JSON.stringify(saved.slice(0, 100)));

      toast('✅ Script protegido e salvo no dashboard!', 'success');
      $('output-section').scrollIntoView({ behavior: 'smooth' });

    } catch (e) {
      toast('Erro de conexão com o Worker. Verifique o WORKER_URL.', 'error');
      console.error(e);
    } finally {
      $('btn-generate').disabled = false;
      $('btn-generate').textContent = '🔒 Gerar Loadstring Protegida';
    }
  });

  // ── copy loadstring ───────────────────────────────────────────────────────
  $('btn-copy').addEventListener('click', () => {
    navigator.clipboard.writeText($('out-loadstring').value)
      .then(() => toast('Loadstring copiada!', 'success'))
      .catch(() => { $('out-loadstring').select(); document.execCommand('copy'); toast('Copiado!'); });
  });

  // ── utilities ─────────────────────────────────────────────────────────────
  function getSaved() {
    try { return JSON.parse(localStorage.getItem('nyxguard_scripts') || '[]'); }
    catch { return []; }
  }

  function toast(msg, type = 'info') {
    const t = document.createElement('div');
    t.className = `toast toast-${type}`;
    t.textContent = msg;
    $('toast-container').appendChild(t);
    requestAnimationFrame(() => t.classList.add('show'));
    setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, 3200);
  }

  // ── clear editor ──────────────────────────────────────────────────────────
  $('btn-clear').addEventListener('click', () => {
    if (!editor.value || confirm('Limpar o editor?')) {
      editor.value = '';
      updateLines();
      $('char-count').textContent = '0 KB';
    }
  });
})();
