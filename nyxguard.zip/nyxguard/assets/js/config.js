/**
 * NyxGuard — Configuração
 * Após fazer o deploy do Worker, cole a URL aqui.
 * Exemplo: https://nyxguard.SEU_USUARIO.workers.dev
 */
window.NYX = {
  WORKER: 'https://nyxguard.SEU_USUARIO.workers.dev',
};
